<?php 
define('DB_USERNAME1', 'lalianca_usuari');
define('DB_PASSWORD1', '12qw0@1F');
define('DB_HOST1', '127.0.0.1');
define('DB_NAME1', 'lalianca_administracio');

//referencia generado con MD5(uniqid(&lt;some_string&gt;, true))
define('API_KEY','G6ig40q+WmSXrX4iLd5EyQ1u4/ZggLO0o7ZtcZYl6Yo=');