<?php

header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS');
header("Access-Control-Allow-Headers: X-Requested-With");
header('Content-Type: text/html; charset=utf-8');
header('P3P: CP="IDC DSP COR CURa ADMa OUR IND PHY ONL COM STA"');

require('../../wp-load.php');

include_once('../include/Config.php');

require '../libs/Slim/vendor/autoload.php';



$app = new \Slim\App();

$app->get('/posts', function ($request, $response, $next) {
    $recent_posts = wp_get_recent_posts();

    if ($recent_posts) {
        return $response->withJson($recent_posts); // Status=200 is default.

    } else {

        return "No se han encontrado posts";
    }
});

$app->get('/events',function($request,$response){
    $query_l = new WP_Query(array (
        'post_type' => 'event',
        'posts_per_page' => 10,
        'orderby' => 'meta_value_num',
        'meta_key' => THEME_NAME . '_event_start',
        'order' => 'ASC'
        )
    ); 
    foreach($query_l->posts as $post){
        $thePostID = $post->ID;
        $options = get_post_meta($thePostID, 'slide_options', true);
        $price =  $options['event_price']['price'];
    };

   //Get Latest Posts
    return $response->withJson($query_l->posts); // Status=200 is default.
});

$app->get('/usuario', function ($request, $response) {
    $headers = apache_request_headers();
    $uName = $_SERVER['PHP_AUTH_USER'];
    $uPass = $_SERVER['PHP_AUTH_PW'];
    $hash = password_hash($uPass, PASSWORD_BCRYPT);

    $mysqli = mysqli_connect(DB_HOST1, DB_USERNAME1, DB_PASSWORD1, DB_NAME1);
    mysqli_set_charset($mysqli, "utf8");
    $login = "SELECT password,soci_id FROM users where username='" . $uName . "'";

    if (!$result = $mysqli->query($login)) {

        die('There was an error running the query: ' . $login . ' [' . $mysqli->error . ']');
    }

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $password = $row['password'];
        $valid = password_verify($uPass, $password);
        if ($valid) {
            $soci_id = $row['soci_id'];
            $soci = "SELECT * FROM socis where id=".$soci_id;

            if (!$rSoci = $mysqli->query($soci)) {

                die('There was an error running the query: ' . $soci . ' [' . $mysqli->error . ']');
            }
            $data = $rSoci->fetch_assoc();
            return $response->withJson($data);
        } else {
            return "Constraseña incorrecta";
        }
    } else
        return "El usuario No Existe";
});

// Run app
$app->run();
